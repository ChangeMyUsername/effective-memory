/******/ (() => { // webpackBootstrap
/*!******************************************!*\
  !*** ../demo1/src/js/pages/my-script.js ***!
  \******************************************/
  (() => { // webpackBootstrap
    /******/    "use strict";
    /*!***********************************************************!*\
      !*** ../demo1/src/js/pages/features/charts/apexcharts.js ***!
      \***********************************************************/
    const primary = '#6993FF';
    const success = '#1BC5BD';
    const info = '#8950FC';
    const warning = '#FFA800';
    const danger = '#F64E60';
    
    var initAll = function () {

        function drawByChannelDoughnutChart() {
            var chartDom = document.getElementById('by-channel');
            var myChart = echarts.init(chartDom);
            var option = {
                title: [
                    {
                        subtext: 'By Channel',
                        left: '23%',
                        top: '75%',
                        textAlign: 'center'
                    }, {
                        subtext: 'By City',
                        left: '50%',
                        top: '75%',
                        textAlign: 'center'
                    }, {
                        subtext: 'By Product',
                        left: '77%',
                        top: '75%',
                        textAlign: 'center'
                    }
                ],
                dataset: [{
                    source: [
                        ['Product', 'Sales', 'Price', 'Year'],
                        ['Cake', 123, 32, 2011],
                        ['Cereal', 231, 14, 2011],
                        ['Tofu', 235, 5, 2011],
                        ['Dumpling', 341, 25, 2011],
                        ['Biscuit', 122, 29, 2011],
                        ['Cake', 143, 30, 2012],
                        ['Cereal', 201, 19, 2012],
                        ['Tofu', 255, 7, 2012],
                        ['Dumpling', 241, 27, 2012],
                        ['Biscuit', 102, 34, 2012],
                        ['Cake', 153, 28, 2013],
                        ['Cereal', 181, 21, 2013],
                        ['Tofu', 395, 4, 2013],
                        ['Dumpling', 281, 31, 2013],
                        ['Biscuit', 92, 39, 2013],
                        ['Cake', 223, 29, 2014],
                        ['Cereal', 211, 17, 2014],
                        ['Tofu', 345, 3, 2014],
                        ['Dumpling', 211, 35, 2014],
                        ['Biscuit', 72, 24, 2014],
                    ],
                }, {
                    transform: {
                        type: 'filter',
                        config: { dimension: 'Year', value: 2011 }
                    },
                }, {
                    transform: {
                        type: 'filter',
                        config: { dimension: 'Year', value: 2012 }
                    }
                }, {
                    transform: {
                        type: 'filter',
                        config: { dimension: 'Year', value: 2013 }
                    }
                }],
                series: [{
                    type: 'pie',
                    radius: ['25%', '35%'],
                    center: ['15%', '70%'],
                    datasetIndex: 1,
                    label: {
                        position: 'inner',
                        fontSize: 14,
                    },
                    labelLine: {
                        show: false
                    }
                }, {
                    type: 'pie',
                    radius: ['25%', '35%'],
                    center: ['48%', '70%'],
                    datasetIndex: 2,
                    label: {
                        position: 'inner',
                        fontSize: 14,
                    },
                    labelLine: {
                        show: false
                    }
                }, {
                    type: 'pie',
                    radius: ['25%', '35%'],
                    center: ['80%', '70%'],
                    datasetIndex: 3,
                    label: {
                        position: 'inner',
                        fontSize: 14,
                    },
                    labelLine: {
                        show: false
                    }
                }],
            
            
                // Optional. Only for responsive layout:
                media: [{
                    query: { minAspectRatio: 1 },
                    option: {
                        series: [
                            { center: ['25%', '50%'] },
                            { center: ['50%', '50%'] },
                            { center: ['75%', '50%'] }
                        ]
                    }
                }, {
                    option: {
                        series: [
                            { center: ['50%', '25%'] },
                            { center: ['50%', '50%'] },
                            { center: ['50%', '75%'] }
                        ]
                    }
                }]
            };
            option && myChart.setOption(option);  
        }

        function drawStackedColumnChart() {
            var chartDom = document.getElementById('stacked-column');
            var myChart = echarts.init(chartDom);
            var option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                        type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                legend: {
                    data: ['SelfCreate', 'NRC', 'Wechat-Walkin', 'Worksite', 'Digital Channel', 'Avg_ticketsize']
                },
                grid: {
                    right: '20%'
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ['31-Jul-2020', '31-Aug-2020', '30-Sep-2020', '31-Oct-2020', '30-Nov-2020', '31-Dec-2020', '31-Jan-2021'],
                        axisLabel: { interval: 0, rotate: 45 }
                    }
                ],
                yAxis: [
                    {
                        name: "Volume",
                        position: 'left',
                        type: 'value',
                        splitLine:{
                            show:false
                        }
                    },
                    {
                        type: 'value',
                        name: 'percentage',
                        position: 'right',
                        splitLine:{
                            show:false
                        }
                    }
                ],
                series: [
                    {
                        name: 'SelfCreate',
                        type: 'bar',
                        stack: 'volume',
                        emphasis: {
                            focus: 'series'
                        },
                        yAxisIndex: 0,
                        data: [320, 332, 301, 334, 390, 330, 320]
                    },
                    {
                        name: 'NRC',
                        type: 'bar',
                        stack: 'volume',
                        emphasis: {
                            focus: 'series'
                        },
                        yAxisIndex: 0,
                        data: [120, 132, 101, 134, 90, 230, 210]
                    },
                    {
                        name: 'Worksite',
                        type: 'bar',
                        stack: 'volume',
                        emphasis: {
                            focus: 'series'
                        },
                        yAxisIndex: 0,
                        data: [89, 44, 61, 67, 90, 45, 33]
                    },
                    {
                        name: 'Avg_Ticketsize',
                        type: 'line',
                        yAxisIndex: 1,
                        data: [20, 40, 70, 80, 25, 67, 19]
                    }
                ]
            };
            option && myChart.setOption(option);
        }

        function drawHorizontalChart() {
            var chartDom = document.getElementById('horizontal-chart');
            var myChart = echarts.init(chartDom);
            var option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {            // Use axis to trigger tooltip
                        type: 'shadow'        // 'shadow' as default; can also be 'line' or 'shadow'
                    }
                },
                legend: {
                    data: ['私人财富规划师的服务素质', '平板分析工具在财富需求分析的实用性', '产品的吸引力', '尊享服务的吸引力', '汇丰品牌的感知']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: {
                    type: 'value'
                },
                yAxis: {
                    type: 'category',
                    data: ['Promoter', 'Passive', 'Detractor']
                },
                series: [
                    {
                        name: '私人财富规划师的服务素质',
                        type: 'bar',
                        stack: 'total',
                        label: {
                            show: true
                        },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [55.84, 10.26, 3.33]
                    },
                    {
                        name: '平板分析工具在财富需求分析的实用性',
                        type: 'bar',
                        stack: 'total',
                        label: {
                            show: true
                        },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [5.19, 15.38, 3.33]
                    },
                    {
                        name: '产品的吸引力',
                        type: 'bar',
                        stack: 'total',
                        label: {
                            show: true
                        },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [15.58, 64.1, 76.67]
                    },
                    {
                        name: '尊享服务的吸引力',
                        type: 'bar',
                        stack: 'total',
                        label: {
                            show: true
                        },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [14.29, 5.13, 10]
                    },
                    {
                        name: '汇丰品牌的感知',
                        type: 'bar',
                        stack: 'total',
                        label: {
                            show: true
                        },
                        emphasis: {
                            focus: 'series'
                        },
                        data: [9.09, 2.56, 6.67]
                    }
                ]
            };
            option && myChart.setOption(option);
        }

        function drawWordCloud () {
            var chart = echarts.init(document.getElementById('word-cloud'));
            chart.setOption({
                series: [{
                    type: 'wordCloud',
                    // The shape of the "cloud" to draw. Can be any polar equation represented as a
                    // callback function, or a keyword present. Available presents are circle (default),
                    // cardioid (apple or heart shape curve, the most known polar equation), diamond (
                    // alias of square), triangle-forward, triangle, (alias of triangle-upright, pentagon, and star.

                    shape: 'circle',
                    // Folllowing left/top/width/height/right/bottom are used for positioning the word cloud
                    // Default to be put in the center and has 75% x 80% size.
                    left: 'center',
                    top: 'center',
                    width: '70%',
                    height: '80%',
                    right: null,
                    bottom: null,
                    // Text size range which the value in data will be mapped to.
                    // Default to have minimum 12px and maximum 60px size.
                    sizeRange: [20, 40],

                    // Text rotation range and step in degree. Text will be rotated randomly in range [-90, 90] by rotationStep 45

                    rotationRange: [-90, 90],
                    rotationStep: 90,

                    // size of the grid in pixels for marking the availability of the canvas
                    // the larger the grid size, the bigger the gap between words.

                    gridSize: 8,

                    // set to true to allow word being draw partly outside of the canvas.
                    // Allow word bigger than the size of the canvas to be drawn
                    drawOutOfBound: true,
                    // If perform layout animation.
                    // NOTE disable it will lead to UI blocking when there is lots of words.
                    layoutAnimation: true,
                    // Global text style
                    textStyle: {
                        fontFamily: 'sans-serif',
                        fontWeight: 'bold',
                        // Color can be a callback function or a color string
                        color: function () {
                            // Random color
                            return 'rgb(' + [
                                Math.round(Math.random() * 160),
                                Math.round(Math.random() * 160),
                                Math.round(Math.random() * 160)
                            ].join(',') + ')';
                        }
                    },
                    emphasis: {
                        focus: 'self',

                        textStyle: {
                            shadowBlur: 10,
                            shadowColor: '#333'
                        }
                    },

                    // Data is an array. Each array item must have name and value property.
                    data: [{
                        name: '财富传承',
                        value: 366
                    },{
                        name: '健康保障',
                        value: 390
                    },
                    {
                        name: '子女教育',
                        value: 421
                    },
                    {
                        name: '父母关爱',
                        value: 401
                    },
                    {
                        name: '家庭教育',
                        value: 378
                    },
                    {
                        name: '探索世界',
                        value: 410
                    },
                    {
                        name: '财富管理',
                        value: 406
                    },
                    ]
                }]
            });
        }
    
        function drawGEOChart() {
    
            const scatterGeo = {
                "海门":[121.15,31.89],
                "鄂尔多斯":[109.781327,39.608266],
                "招远":[120.38,37.35],
                "舟山":[122.207216,29.985295],
                "齐齐哈尔":[123.97,47.33],
                "盐城":[120.13,33.38],
                "赤峰":[118.87,42.28],
                "青岛":[120.33,36.07],
                "乳山":[121.52,36.89],
                "金昌":[102.188043,38.520089],
                "泉州":[118.58,24.93],
                "莱西":[120.53,36.86],
                "日照":[119.46,35.42],
                "胶南":[119.97,35.88],
                "南通":[121.05,32.08],
                "拉萨":[91.11,29.97],
                "云浮":[112.02,22.93],
                "梅州":[116.1,24.55],
                "文登":[122.05,37.2],
                "上海":[121.48,31.22],
                "攀枝花":[101.718637,26.582347],
                "威海":[122.1,37.5],
                "承德":[117.93,40.97],
                "厦门":[118.1,24.46],
                "汕尾":[115.375279,22.786211],
                "潮州":[116.63,23.68],
                "丹东":[124.37,40.13],
                "太仓":[121.1,31.45],
                "曲靖":[103.79,25.51],
                "烟台":[121.39,37.52],
                "福州":[119.3,26.08],
                "瓦房店":[121.979603,39.627114],
                "即墨":[120.45,36.38],
                "抚顺":[123.97,41.97],
                "玉溪":[102.52,24.35],
                "张家口":[114.87,40.82],
                "阳泉":[113.57,37.85],
                "莱州":[119.942327,37.177017],
                "湖州":[120.1,30.86],
                "汕头":[116.69,23.39],
                "昆山":[120.95,31.39],
                "宁波":[121.56,29.86],
                "湛江":[110.359377,21.270708],
                "揭阳":[116.35,23.55],
                "荣成":[122.41,37.16],
                "连云港":[119.16,34.59],
                "葫芦岛":[120.836932,40.711052],
                "常熟":[120.74,31.64],
                "东莞":[113.75,23.04],
                "河源":[114.68,23.73],
                "淮安":[119.15,33.5],
                "泰州":[119.9,32.49],
                "南宁":[108.33,22.84],
                "营口":[122.18,40.65],
                "惠州":[114.4,23.09],
                "江阴":[120.26,31.91],
                "蓬莱":[120.75,37.8],
                "韶关":[113.62,24.84],
                "嘉峪关":[98.289152,39.77313],
                "广州":[113.23,23.16],
                "延安":[109.47,36.6],
                "太原":[112.53,37.87],
                "清远":[113.01,23.7],
                "中山":[113.38,22.52],
                "昆明":[102.73,25.04],
                "寿光":[118.73,36.86],
                "盘锦":[122.070714,41.119997],
                "长治":[113.08,36.18],
                "深圳":[114.07,22.62],
                "珠海":[113.52,22.3],
                "宿迁":[118.3,33.96],
                "咸阳":[108.72,34.36],
                "铜川":[109.11,35.09],
                "平度":[119.97,36.77],
                "佛山":[113.11,23.05],
                "海口":[110.35,20.02],
                "江门":[113.06,22.61],
                "章丘":[117.53,36.72],
                "肇庆":[112.44,23.05],
                "大连":[121.62,38.92],
                "临汾":[111.5,36.08],
                "吴江":[120.63,31.16],
                "石嘴山":[106.39,39.04],
                "沈阳":[123.38,41.8],
                "苏州":[120.62,31.32],
                "茂名":[110.88,21.68],
                "嘉兴":[120.76,30.77],
                "长春":[125.35,43.88],
                "胶州":[120.03336,36.264622],
                "银川":[106.27,38.47],
                "张家港":[120.555821,31.875428],
                "三门峡":[111.19,34.76],
                "锦州":[121.15,41.13],
                "南昌":[115.89,28.68],
                "柳州":[109.4,24.33],
                "三亚":[109.511909,18.252847],
                "自贡":[104.778442,29.33903],
                "吉林":[126.57,43.87],
                "阳江":[111.95,21.85],
                "泸州":[105.39,28.91],
                "西宁":[101.74,36.56],
                "宜宾":[104.56,29.77],
                "呼和浩特":[111.65,40.82],
                "成都":[104.06,30.67],
                "大同":[113.3,40.12],
                "镇江":[119.44,32.2],
                "桂林":[110.28,25.29],
                "张家界":[110.479191,29.117096],
                "宜兴":[119.82,31.36],
                "北海":[109.12,21.49],
                "西安":[108.95,34.27],
                "金坛":[119.56,31.74],
                "东营":[118.49,37.46],
                "牡丹江":[129.58,44.6],
                "遵义":[106.9,27.7],
                "绍兴":[120.58,30.01],
                "扬州":[119.42,32.39],
                "常州":[119.95,31.79],
                "潍坊":[119.1,36.62],
                "重庆":[106.54,29.59],
                "台州":[121.420757,28.656386],
                "南京":[118.78,32.04],
                "滨州":[118.03,37.36],
                "贵阳":[106.71,26.57],
                "无锡":[120.29,31.59],
                "本溪":[123.73,41.3],
                "克拉玛依":[84.77,45.59],
                "渭南":[109.5,34.52],
                "马鞍山":[118.48,31.56],
                "宝鸡":[107.15,34.38],
                "焦作":[113.21,35.24],
                "句容":[119.16,31.95],
                "北京":[116.46,39.92],
                "徐州":[117.2,34.26],
                "衡水":[115.72,37.72],
                "包头":[110,40.58],
                "绵阳":[104.73,31.48],
                "乌鲁木齐":[87.68,43.77],
                "枣庄":[117.57,34.86],
                "杭州":[120.19,30.26],
                "淄博":[118.05,36.78],
                "鞍山":[122.85,41.12],
                "溧阳":[119.48,31.43],
                "库尔勒":[86.06,41.68],
                "安阳":[114.35,36.1],
                "开封":[114.35,34.79],
                "济南":[117,36.65],
                "德阳":[104.37,31.13],
                "温州":[120.65,28.01],
                "九江":[115.97,29.71],
                "邯郸":[114.47,36.6],
                "临安":[119.72,30.23],
                "兰州":[103.73,36.03],
                "沧州":[116.83,38.33],
                "临沂":[118.35,35.05],
                "南充":[106.110698,30.837793],
                "天津":[117.2,39.13],
                "富阳":[119.95,30.07],
                "泰安":[117.13,36.18],
                "诸暨":[120.23,29.71],
                "郑州":[113.65,34.76],
                "哈尔滨":[126.63,45.75],
                "聊城":[115.97,36.45],
                "芜湖":[118.38,31.33],
                "唐山":[118.02,39.63],
                "平顶山":[113.29,33.75],
                "邢台":[114.48,37.05],
                "德州":[116.29,37.45],
                "济宁":[116.59,35.38],
                "荆州":[112.239741,30.335165],
                "宜昌":[111.3,30.7],
                "义乌":[120.06,29.32],
                "丽水":[119.92,28.45],
                "洛阳":[112.44,34.7],
                "秦皇岛":[119.57,39.95],
                "株洲":[113.16,27.83],
                "石家庄":[114.48,38.03],
                "莱芜":[117.67,36.19],
                "常德":[111.69,29.05],
                "保定":[115.48,38.85],
                "湘潭":[112.91,27.87],
                "金华":[119.64,29.12],
                "岳阳":[113.09,29.37],
                "长沙":[113,28.21],
                "衢州":[118.88,28.97],
                "廊坊":[116.7,39.53],
                "菏泽":[115.480656,35.23375],
                "合肥":[117.27,31.86],
                "武汉":[114.31,30.52],
                "大庆":[125.03,46.58]
            };
            //城市数据
            const scatterVal = [
                {name: "上海", value: 250000},
                {name: "广州", value: 384532},
                {name: "深圳", value: 512245},
                {name: "北京", value: 7954323},
                {name: "杭州", value: 244323},
            ];
            //数据转换，转换后的格式：[{name: 'cityName', value: [lng, lat, val]}, {...}]
            const convertScatterData = function(data) {
                let res = [];
                for(let i=0;i<data.length;i++) {
                    let geoCoord = scatterGeo[data[i].name];
                    if(geoCoord) {
                        res.push({
                            name: data[i].name,
                            value: geoCoord.concat(data[i].value)
                        });
                    }
                }
                return res;
            };
            const scatterMap = echarts.init(document.getElementById("scatter-map"));
            //地图配置项
            const sactterMapOpt = {
                legend: {
                    data: ['Value'], //与series的name属性对应
                    orient: 'vertical',
                    y: 'bottom',
                    x: 'right',
                    textStyle: {
                        color: '#fff'
                    }
                },
                tooltip: {
                    trigger: 'item',
                    formatter: function(params) {
                        return params.name + ' : ' + params.value[2];
                    }
                },
                visualMap: {
                    min: 0,
                    max: 10000000,
                    calculable: true,
                    inRange: {
                        color: ['#50a3ba', '#eac736', '#d94e5d']
                    },
                    textStyle: {
                        color: '#fff'
                    }
                },
                geo: {
                    map: 'china',
                    roam: false, //开启鼠标缩放和漫游
                    zoom: 1, //地图缩放级别
                    selectedMode: false, //选中模式：single | multiple
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 0,
                    layoutCenter: ['50%', '50%'], //设置后left/right/top/bottom等属性无效
                    layoutSize: '100%',
                    label: {
                        emphasis: {
                            show: false
                        }
                    },
                    itemStyle: {
                        normal: {
                            areaColor: '#101f32',
                            borderWidth: 1.1,
                            borderColor: '#43d0d6'
                        },
                        emphasis: {
                            areaColor: '#069'
                        }
                    }
                },
                series: [{
                    name: 'Value',
                    type: 'scatter',
                    coordinateSystem: 'geo',
                    symbolSize: 12,
                    label: {
                        normal: {
                            show: false
                        },
                        emphasis: {
                            show: false
                        }
                    },
                    itemStyle: {
                        emphasis: {
                            borderColor: '#fff',
                            borderWidth: 1
                        }
                    },
                    data: convertScatterData(scatterVal)
                }]
            };
            //渲染报表
            scatterMap.setOption(sactterMapOpt);
        }

        function drawPWPProductivityChart() {
            var chartDom = document.getElementById('pwp-productivity');
            var myChart = echarts.init(chartDom);
            var option;

            option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                        type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                legend: {
                    data: ['GZ', 'HZ', 'SZ', 'SH', 'Avg_Ticketsize']
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ['05/Jul/2020', '12/Jul/2020', '19/Jul/2020', '26/Jul/2020', '31/Jul/2020', '02/Aug/2020', '09/Aug/2020', '16/Aug/2020', '23/Aug/2020', '31/Aug/2020', '13/Sep/2020', '20/Sep/2020'],
                        axisPointer: {
                            type: 'shadow'
                        },
                        axisLabel: { interval: 0, rotate: 45 }
                    }
                ],
                yAxis: [
                    {
                        type: 'value',
                        name: 'Volume',
                        splitLine:{
                            show:false
                        }
                    },
                    {
                        type: 'value',
                        name: 'productivity',
                        splitLine:{
                            show:false
                        }
                    }
                ],
                series: [
                    {
                        name: 'GZ',
                        type: 'bar',
                        data: [8549, 310, 10354, 9278, 5760, 1822, 4734, 8979, 8947, 8454, 8304, 8]
                    },
                    {
                        name: 'HZ',
                        type: 'bar',
                        data: [5272, 3318, 10282, 10607, 11671, 1832, 7227, 3190, 11021, 2577, 6826, 11877]
                    },
                    {
                        name: 'SZ',
                        type: 'bar',
                        data: [7312, 1494, 6526, 10225, 1021, 4271, 11823, 7310, 2318, 5397, 6537, 7843]
                    },
                    {
                        name: 'SH',
                        type: 'bar',
                        data: [7833, 10778, 5076, 9442, 4202, 11066, 10424, 2042, 11484, 1149, 2756, 9943]
                    },
                    {
                        name: 'Avg_Ticketsize',
                        type: 'line',
                        yAxisIndex: 1,
                        data: [1.18, 0.62, 0.73, 0.93, 0.73, 1.13, 0.83, 1.05, 0.11, 0.63, 1.11, 0.13]
                    }
                ]
            };

            option && myChart.setOption(option);
        }

        function drawFunnelChart() {
            var myChart = echarts.init(document.getElementById('funnel-chart'));
            var option = {
                tooltip: {
                    trigger: 'item',
                    formatter: "{a} <br/>{b}"
                },
            
                series: [
                    {
                        name:'Convert Percentage',
                        type:'funnel',
                        left: '10%',
                        top: 60,
                        //x2: 80,
                        bottom: 60,
                        width: '80%',
                        // height: {totalHeight} - y - y2,
                        min: 0,
                        max: 100,
                        minSize: '0%',
                        maxSize: '100%',
                        sort: 'descending',
                        gap: 2,
                        label: {
                            show: true,
                            position: 'inside'
                        },
                        labelLine: {
                            length: 10,
                            lineStyle: {
                                width: 1,
                                type: 'solid'
                            }
                        },
                        itemStyle: {
                            borderColor: '#fff',
                            borderWidth: 1
                        },
                        emphasis: {
                            label: {
                                fontSize: 20
                            }
                        },
                        data: [
                            {value: 16, name: '7. Policy Effective 2.6%'},
                            {value: 30, name: '6. Policy Submitted 3.7%'},
                            {value: 44, name: '5. Prospect FNA 16.5%'},
                            {value: 58, name: '4. Prospect Meeting 32.5%'},
                            {value: 72, name: '3. Prospect Contacted 96%'},
                            {value: 86, name: '2. Prospect Actioned 96.9%'},
                            {value: 100, name: '1. Prospect Assigned 100%'}
                        ]
                    }
                ]
            };
            
            option && myChart.setOption(option);
        }
    
    
        return {
            // public functions
            init: function () {
                drawGEOChart();
                drawByChannelDoughnutChart();
                drawStackedColumnChart();
                drawHorizontalChart();
                drawWordCloud();
                drawPWPProductivityChart();
                drawFunnelChart();
            }
        };
    }();
    
    jQuery(document).ready(function () {
        initAll.init();
    });
    
    /******/ })();
    
    /******/ })()
    ;
    //# sourceMappingURL=my-script.js.map